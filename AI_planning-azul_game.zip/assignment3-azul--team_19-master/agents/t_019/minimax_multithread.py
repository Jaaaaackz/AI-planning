from template import Agent
import random
import math
from copy import deepcopy
import concurrent.futures
import traceback
from numpy import argmax
from Azul.azul_model import AzulGameRule as GameRule

THINKTIME   = 0.9
NUM_PLAYERS = 2
MAX_DEPTH = 1

class myAgent(Agent):
    def __init__(self, _id):
        self.id = _id # Agent needs to remember its own id.
        self.game_rule = GameRule(NUM_PLAYERS) # Agent stores an instance of GameRule, from which to obtain functions.
        # More advanced agents might find it useful to not be bound by the functions in GameRule, instead executing
        # their own custom functions under GetActions and DoAction.

    def SelectAction(self, actions, root_state):
        # action, _ = self.minimax(root_state, MAX_DEPTH, -math.inf, math.inf, True)
        # return action
        try:
            legal_actions = self.game_rule.getLegalActions(root_state, self.id)
            n_actions = len(legal_actions)
            threads = [None] * n_actions
            values = []

            with concurrent.futures.ThreadPoolExecutor(max_workers = n_actions) as executor:
                for n, a in enumerate(legal_actions):
                    dummy = deepcopy(root_state)
                    next_state = self.game_rule.generateSuccessor(dummy, a, self.id)
                    threads[n] = executor.submit(self.minimax, next_state, MAX_DEPTH, -math.inf, math.inf, False)

                for future in concurrent.futures.as_completed(threads):
                    values.append(future.result())
            
            print(len(values), len(legal_actions))
            return legal_actions[argmax(values)]

        except:
            traceback.print_exc()
            return random.choice(actions)

    def minimax(self, game_state, depth, alpha, beta, maximise=True):
        # check whether the game end
        end_of_game = False
        for state in game_state.agents:
            if state.GetCompletedRows() > 0:
                end_of_game = True
                break

        # check whether the round end
        end_of_round = False
        if not end_of_game and game_state.TilesRemaining() == 0:
            end_of_round = True

        # base case
        if end_of_game or end_of_round or depth == 0:
            game_state_copy = deepcopy(game_state)
            value = game_state_copy.agents[self.id].ScoreRound()[0]
            # value = game_state_copy.agents[self.id].score     #-game_state.agents[self.id * -1 + 1].score
            return value

        # max case
        if maximise:
            max_value = -math.inf
            moves = self.game_rule.getLegalActions(game_state, self.id)

            for move in moves:
                game_state_copy = deepcopy(game_state)
                next_game_state = self.game_rule.generateSuccessor(game_state_copy, move, self.id)

                value = self.minimax(next_game_state, depth - 1, alpha, beta, False)
                max_value = max(max_value, value)

                alpha = max(alpha, value)
                if alpha >= beta:
                    break

            return max_value

        # min case
        else:
            min_value = math.inf
            moves = self.game_rule.getLegalActions(game_state, self.id * -1 + 1)

            for move in moves:
                game_state_copy = deepcopy(game_state)
                next_game_state = self.game_rule.generateSuccessor(game_state_copy, move, self.id * -1 + 1)

                value = self.minimax(next_game_state, depth - 1, alpha, beta, True)
                min_value = min(min_value, value)

                beta = min(beta, value)
                if alpha >= beta:
                    break

            return min_value