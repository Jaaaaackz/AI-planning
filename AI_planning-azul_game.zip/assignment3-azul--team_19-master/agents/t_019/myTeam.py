from template import Agent
import math
import copy
from Azul.azul_model import AzulGameRule as GameRule

THINKTIME = 0.9
NUM_PLAYERS = 2
THRESHOLD = 8


class myAgent(Agent):
    def __init__(self, _id):
        self.id = _id  # Agent needs to remember its own id.
        self.game_rule = GameRule(NUM_PLAYERS)  # Agent stores an instance of GameRule, from which to obtain functions.
        # More advanced agents might find it useful to not be bound by the functions in GameRule, instead executing
        # their own custom functions under GetActions and DoAction.

    def SelectAction(self, actions, root_state):
        if len(actions) > 60:
            depth = 3
        elif len(actions) > 10:
            depth = 4
        else:
            depth = 5

        action, _ = self.minimax(root_state, depth, -math.inf, math.inf, True)

        return action

    def getLineEmptyBlocks(self, plr_state, line_dest, num_to_pattern_line):
        if plr_state.lines_tile[line_dest] != -1:
            # line already used
            occupied_blocks = plr_state.lines_number[line_dest]
            empty_blocks = (line_dest + 1) - (occupied_blocks + num_to_pattern_line)
        else:
            # line never used, check for integrity
            assert plr_state.lines_number[line_dest] == 0
            empty_blocks = (line_dest + 1) - num_to_pattern_line
        return empty_blocks

    def filterActions(self, actions, plr_state):
        dict = {}

        if len(actions) > THRESHOLD:
            for a in actions:
                tile_type = a[2].tile_type
                pattern_line_dest = a[2].pattern_line_dest
                num_to_pattern_line = a[2].num_to_pattern_line
                num_to_floor_line = a[2].num_to_floor_line

                # skip action if more than 1 penalty
                if num_to_floor_line > 1 or pattern_line_dest == -1:
                    continue

                # get number of empty blocks in the destination line
                empty_blocks = self.getLineEmptyBlocks(plr_state, pattern_line_dest, num_to_pattern_line)

                useless = empty_blocks + num_to_floor_line
                diff = num_to_pattern_line - num_to_floor_line
                key = (tile_type, pattern_line_dest)

                if (key not in dict) or (diff > dict[key][2]):
                    dict[key] = (a, useless, diff)

            action_sorted = sorted(dict.items(), key=lambda x: x[1][1])
            action_filtered = [item[1][0] for item in action_sorted][:THRESHOLD]
            return action_filtered

        return actions

    def minimax(self, game_state, depth, alpha, beta, maximise=True):
        # check whether the game end
        end_of_game = False
        for state in game_state.agents:
            if state.GetCompletedRows() > 0:
                end_of_game = True
                break

        # check whether the round end
        end_of_round = False
        if not end_of_game and game_state.TilesRemaining() == 0:
            end_of_round = True

        # base case
        if end_of_game or end_of_round or depth == 0:
            game_state_copy = copy.deepcopy(game_state)
            value = game_state_copy.agents[self.id].ScoreRound()[0]
            game_state_copy.agents[self.id].EndOfGameScore()
            value = game_state_copy.agents[self.id].score  # -game_state.agents[self.id * -1 + 1].score
            return (None, value)

        # max case
        if maximise:
            max_value = -math.inf
            moves = self.game_rule.getLegalActions(game_state, self.id)
            plr_state = game_state.agents[self.id]
            filtered_moves = self.filterActions(moves, plr_state)
            best_move = moves[0]

            for move in filtered_moves:
                game_state_copy = copy.deepcopy(game_state)
                next_game_state = self.game_rule.generateSuccessor(game_state_copy, move, self.id)

                value = self.minimax(next_game_state, depth - 1, alpha, beta, False)[1]
                if value > max_value:
                    max_value = value
                    best_move = move

                alpha = max(alpha, value)
                if alpha >= beta:
                    break

            return best_move, max_value

        # min case
        else:
            min_value = math.inf
            moves = self.game_rule.getLegalActions(game_state, self.id * -1 + 1)
            plr_state = game_state.agents[self.id * -1 + 1]
            filtered_moves = self.filterActions(moves, plr_state)
            best_move = moves[0]

            for move in filtered_moves:
                game_state_copy = copy.deepcopy(game_state)
                next_game_state = self.game_rule.generateSuccessor(game_state_copy, move, self.id * -1 + 1)

                value = self.minimax(next_game_state, depth - 1, alpha, beta, True)[1]
                if value < min_value:
                    min_value = value
                    best_move = move

                beta = min(beta, value)
                if alpha >= beta:
                    break

            return best_move, min_value