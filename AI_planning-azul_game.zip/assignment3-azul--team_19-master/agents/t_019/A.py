from template import Agent
import random
import time, random,heapq
from Azul.azul_model import AzulGameRule as GameRule
from copy import deepcopy
import copy

THINKTIME   = 0.9
NUM_PLAYERS = 2


class myAgent(Agent):
    def __init__(self, _id):
        self.id = _id
        self.game_rule = GameRule(NUM_PLAYERS) 

    def GetActions(self, state):
        return self.game_rule.getLegalActions(state, self.id)
    
    def DoAction(self, state, action):
        score = state.agents[self.id].score
        state = self.game_rule.generateSuccessor(state, action, self.id)
        
        goal_reached = False
        
        return goal_reached

    def SelectAction(self, actions, rootstate):
        start_time = time.time()

        priority_queue = [PriorityQueueNode(deepcopy(rootstate), [], 0)]

        # Initialize the best heuristic value and its corresponding action
        best_heuristic_value = float('-inf')
        best_action = None
    
        while priority_queue and time.time() - start_time < THINKTIME:
            current_node = heapq.heappop(priority_queue)
            state, path, _ = current_node.state, current_node.path, current_node.priority

            new_actions = self.GetActions(state)

            # Filter out ENDROUND and STARTROUND actions
            new_actions = [a for a in new_actions if a not in ["ENDROUND", "STARTROUND"]]
        
            for a in new_actions:
                next_state = deepcopy(state)
                next_path = path + [a]
                goal = self.DoAction(next_state, a)
                if goal:
                    print(f'Move {self.turn_count}, path found:', next_path)
                    return next_path[0]

                heuristic_value = self.heuristic(next_state)
                
                # Update the best heuristic value and its corresponding action
                if heuristic_value > best_heuristic_value:
                    best_heuristic_value = heuristic_value
                    best_action = a

                heapq.heappush(priority_queue, PriorityQueueNode(next_state, next_path, heuristic_value))
        if best_action is not None:
            print("A* best action: ", best_action)
        else:
            best_action = random.choice(actions)
            print("A* random action: ", best_action)
        return best_action



    def heuristic(self, state):
        dummy = deepcopy(state)

        ''' consider the opponent's score '''
        # use current scores
        # return state.agents[self.id].score - state.agents[self.id * -1 + 1].score

        # use end of round scores
        # score_this = dummy.agents[self.id].ScoreRound()[0]
        # score_that = dummy.agents[self.id * -1 + 1].ScoreRound()[0]
        # return score_this - score_that

        # use end of game scores (with bonus)
        # dummy.agents[self.id].ScoreRound()
        # dummy.agents[self.id * -1 + 1].ScoreRound()
        # score_this = self.game_rule.calScore(dummy, self.id)
        # score_that = self.game_rule.calScore(dummy, self.id * -1 + 1)
        # return score_this - score_that

        ''' greedy: only consider self scores'''
        # use current score
        # return state.agents[self.id].score

        # use end of round score
        # return dummy.agents[self.id].ScoreRound()[0]

        # use end of game score (with bonus)
        dummy.agents[self.id].ScoreRound()
        return self.game_rule.calScore(dummy, self.id)

class PriorityQueueNode:
    def __init__(self, state, path, priority):
        self.state = state
        self.path = path
        self.priority = priority

    def __lt__(self, other):
        return self.priority < other.priority
