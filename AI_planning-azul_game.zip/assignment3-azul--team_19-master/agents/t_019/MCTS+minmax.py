import time
import random
from Azul.azul_model import AzulGameRule as GameRule
from copy import deepcopy
import copy
import math

THINKTIME = 0.9
NUM_PLAYERS = 2


class myAgent():
    def __init__(self, _id,):
        self.id = _id
        self.game_rule = GameRule(NUM_PLAYERS)
        self.rollout_depth = 0

    def GetActions(self, state):
        return self.game_rule.getLegalActions(state, self.id)

    def DoAction(self, state, action):
        new_state = self.game_rule.generateSuccessor(state, action, self.id)
        goal_reached = self.game_rule.gameEnds()
        return new_state, goal_reached


    def SelectAction(self, actions, rootstate):
        start_time = time.time()
        root = Node(rootstate)
        while time.time() - start_time < THINKTIME:
            node = self.select_node(root)
            reward = self.rollout(node.state)
            print("Reward:",reward)
            self.backpropagate(node, reward)

            best_child = self.choose_best_child(root)
            best_action = self.find_first_action(root, best_child)

        print("Child: ",best_child)
        print("Action:",best_action)
        return best_action

    def find_first_action(self, root, best_child):
        current_node = best_child
        while current_node.parent != root:
            current_node = current_node.parent
        return current_node.action

    def select_node(self, node):
        while True:
            if not node.children:
                actions = self.GetActions(node.state)
                if actions:
                    node = self.expand(node)
                else:
                    return node
            else:
                node = self.best_uct(node)
                if not node.children:
                    return node


    def expand(self, node):
        actions = self.GetActions(node.state)
        for action in actions:
            child_state, goal_reached = self.DoAction(deepcopy(node.state), action)
            initial_value = child_state.agents[self.id].ScoreRound()[0] if not goal_reached else 0
            child = Node(child_state, parent=node, action=action, initial_value=initial_value)
            node.add_child(child)

            # Perform a rollout for the child node and update its visits and value
            child.visits += 1
            child.value += self.rollout(child_state)

            if goal_reached:
                break

        return node.children[0]


    def best_uct(self, node):
        best_value = float('-inf')
        best_child = None

        for child in node.children:
            uct_value = child.value / child.visits + 0.5 * (2 * child.visits) ** 0.5
            if uct_value > best_value:
                best_value = uct_value
                best_child = child
        return best_child

    def rollout(self, state):
        while not self.is_terminal(state):
            actions = self.game_rule.getLegalActions(state, self.id)
            if not actions:  # If there are no legal actions, break the loop
                break
            best_action, _ = self.minimax(state, 0, True)
            if best_action is None:
                best_action = random.choice(actions)
            state, goal_reached = self.DoAction(deepcopy(state), best_action) 
            
            if goal_reached:
                break
        reward = self.get_reward(state)  
        return reward



    def is_terminal(self, state):
        end_of_game=False
        for state in state.agents:
            if state.GetCompletedRows() > 0:
                end_of_game = True
        return end_of_game

    def get_reward(self, state):
        # consider the opponent's score
        return state.agents[self.id].score - state.agents[self.id * -1 + 1].score

    def backpropagate(self, node, reward):
        while node:
            node.visits += 1
            node.value += reward
            node = node.parent

    def choose_best_child(self, node):
        best_value = float('-inf')
        best_child = None

        for child in node.children:
            if child.visits > best_value:
                best_value = child.visits
                best_child = child

        return best_child

    def minimax(self, game_state, depth, max=True):
        # check whether the game end
        end_of_game = False
        for state in game_state.agents:
            if state.GetCompletedRows() > 0:
                end_of_game = True
                break

        # check whether the round end
        end_of_round = False
        if not end_of_game and game_state.TilesRemaining() == 0:
            end_of_round = True

        # base case
        if end_of_game or end_of_round or depth == 1:
            game_state_copy = copy.deepcopy(game_state)
            value = game_state_copy.agents[self.id].ScoreRound()[0]
            # value = game_state_copy.agents[self.id].score     #-game_state.agents[self.id * -1 + 1].score
            return (None, value)

        # max case
        if max:
            max_value = -math.inf
            moves = self.game_rule.getLegalActions(game_state, self.id)
            best_move = moves[0]

            for move in moves:
                game_state_copy = copy.deepcopy(game_state)
                next_game_state = self.game_rule.generateSuccessor(game_state_copy, move, self.id)
                value = self.minimax(next_game_state, depth+1, False)[1]
                if value > max_value:
                    max_value = value
                    best_move = move

            return best_move, max_value

        # min case
        else:
            min_value = math.inf
            moves = self.game_rule.getLegalActions(game_state, self.id * -1 + 1)
            best_move = moves[0]

            for move in moves:
                game_state_copy = copy.deepcopy(game_state)
                next_game_state = self.game_rule.generateSuccessor(game_state_copy, move, self.id * -1 + 1)
                value = self.minimax(next_game_state, depth+1, True)[1]
                if value < min_value:
                    min_value = value
                    best_move = move

            return best_move, min_value


class Node:
    def __init__(self, state, parent=None, action=None, initial_value=0):
        self.state = state
        self.parent = parent
        self.children = []
        self.visits = 0
        self.value = initial_value
        self.action = action

    def add_child(self, child):
        self.children.append(child)
