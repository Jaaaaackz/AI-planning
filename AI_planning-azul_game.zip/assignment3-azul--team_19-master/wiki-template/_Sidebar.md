1. [Home and Introduction](https://github.com/COMP90054-classroom/pacman-contest-agent/wiki)
2. [Problem Analysis](Problem-Analysis)

    2.1 [Approach One](AI-Method-1)

    2.2 [Approach Two](AI-Method-2)

    2.3 [Approach Three](AI-Method-3)
3. [Evolution and Experiments](Evolution)
4. [Conclusions and Reflections](Conclusions-and-Reflections)
